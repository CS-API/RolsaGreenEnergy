﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RolsaGreenEnergy
{
    public partial class Settings : Form
    {
        public Settings()
        {
            InitializeComponent();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            //Logges the user out and switches the account details to the original
            AccountDetails.IsLoggedIn = false;
            AccountDetails.password = null;
            AccountDetails.UserName = null;
            AccountDetails.Admin = false;
            AccountDetails.bgColour = "White";
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Changes the bg colour on the account details
            string bg = bgColour.Text;

            //checks if the user hasnt entered anything and just sets it to the default colour
            if (bg.Length == 0)
            {
                bg = "White";

                AccountDetails.bgColour = bg;
            }
            else
            {
                AccountDetails.bgColour = bg;
            }

            
            
               
        }
                
            

            
    }

        
}
