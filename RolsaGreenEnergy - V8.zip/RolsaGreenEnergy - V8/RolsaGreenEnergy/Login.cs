﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RolsaGreenEnergy
{
    public partial class Login : Form
    {
        //Variable to check if the user is logged in
        bool loggedIn = false;
        bool stop = false;
        bool emailCorrect = false;
        
        public Login()
        {
            InitializeComponent();
            
        }

        

        private void btnHome_Click(object sender, EventArgs e)
        {
            //Takes the user to the home page.
            this.Hide();
            homePage homePage = new homePage();
            homePage.ShowDialog();
            
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            //Takes the user to the information page
            this.Hide();
            Information info = new Information();
            info.ShowDialog();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            //Searches the databasr to see if the users inputs are in the account database and logs them in if the password is correct.
            string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("FindAccounts", sqlConnection);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(command);

            DataTable dt = new DataTable();

            sqlConnection.Open();

            sd.Fill(dt);

            sqlConnection.Close();

            //Checks the database for  the email and if correct it will check the password.
            foreach (DataRow dr in dt.Rows)
            {
                if (txtEmail.Text.Equals(dr["Email"].ToString()))
                {
                    if (txtPassword.Text.Equals(dr["Password"].ToString()))
                    {
                        if (dr["StaffPermisions"].ToString().Equals("True"))
                        {
                            //Checks if the user has admin permssisions and makes it true if not it logges them in as staff.
                            if (dr["AdminPermissions"].ToString().Equals("True"))
                            {
                                loggedIn = true;
                                AccountDetails.UserName = (txtEmail.Text);
                                AccountDetails.password = (txtPassword.Text);
                                AccountDetails.IsLoggedIn = true;
                                AccountDetails.staff = true;
                                AccountDetails.Admin = true;
                                stop = true;
                                break;
                            }
                            else
                            {
                                loggedIn = true;
                                AccountDetails.UserName = (txtEmail.Text);
                                AccountDetails.password = (txtPassword.Text);
                                AccountDetails.IsLoggedIn = true;
                                AccountDetails.staff = true;
                                stop = true;
                                break;
                            }
                        }
                        else
                        {
                            loggedIn = true;
                            AccountDetails.UserName = (txtEmail.Text);
                            AccountDetails.password = (txtPassword.Text);
                            AccountDetails.IsLoggedIn = true;
                            AccountDetails.staff = false;
                            stop = true;
                            break;
                        }
                            


                    }
                    else
                    {
                        emailCorrect = true;
                        txtPassword.Clear();
                        MessageBox.Show("Incorret Password, Try Again");
                        break;
                    }

                }
                else
                {
                    loggedIn = false;
                    stop = false;
                    emailCorrect = false;
                }
                        
  
            }

            //See if the programme should stop, thi could be due to the email not being found.
            if (stop == false)
            {
                //checks if the email is correct so all the user has to do is to re enter it
                if (emailCorrect == false)
                {
                    //checked if the user is logged in and if not asks if they want to register an account
                    if (loggedIn == false)
                    {
                        //Asks the user if they want to Register an account as they do not alrerady have one.
                        DialogResult dialogResult = MessageBox.Show("Email Not found, do you want to Register an account?", "Register?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (dialogResult == DialogResult.Yes)
                        {
                            try
                            {
                                //If the user wants to register an account it will add them to the database with the email and password they have added
                                string ConnectionString2 = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

                                SqlConnection sqlConnection2 = new SqlConnection(ConnectionString2);
                                SqlCommand command2 = new SqlCommand("RegisterAccount", sqlConnection2);
                                command2.CommandType = CommandType.StoredProcedure;

                                command2.Parameters.AddWithValue("@Email", txtEmail.Text);
                                command2.Parameters.AddWithValue("@Password", txtPassword.Text);
                                command2.Parameters.AddWithValue("@StaffPermisions", "False");
                                command2.Parameters.AddWithValue("@AdminPermissions", "False");

                                sqlConnection2.Open();

                                command2.ExecuteNonQuery();

                                sqlConnection2.Close();

                                MessageBox.Show("Success, Registerd Account. You can now log in", "Registered", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch
                            {
                                MessageBox.Show("Error, Unable to Register Account try again", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                txtEmail.Text = "Email....";
                                txtPassword.Text = "Password....";
                                checkBox1.Checked = true;
                           }
                        }
                        else
                        {
                            //Clears the text boxes and replaces tem with what orignally was their.
                            txtEmail.Clear();
                            txtPassword.Clear();

                            txtEmail.Text = "Email....";
                            txtPassword.PasswordChar = '\0';
                            txtPassword.Text = "Password....";
                            checkBox1.Checked = true;

                        }
                    }
                }


            }
            else
            {
                //Checks if they have staff permissions so they go to a seperate login page
                if (AccountDetails.staff == true)
                {
                    this.Hide();
                    StaffLoggedIn staffAccount = new StaffLoggedIn();
                    staffAccount.ShowDialog();
                }
                else
                {
                    this.Hide();
                    LoggedInAccount userLoggedIn = new LoggedInAccount();
                    userLoggedIn.ShowDialog();
                }
            }
            
        }

            private void txtEmail_TextChanged(object sender, EventArgs e)
            {
                //Clears the text already in the text box so the user can type their email.
                txtEmail.Clear();
            }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            //clears the email box ans makes the password character * so other people cant see the users password.
            txtPassword.Clear();
            txtPassword.PasswordChar = '*';
            checkBox1.Checked = false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //Allows the user to check their password and rehide it.
            if (checkBox1.Checked)
            {
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.PasswordChar = '*';
            }
        }

        private void Account_Load(object sender, EventArgs e)
        {
            //Changes the backgound colour if the user has changed it in their settings.
            this.BackColor = Color.FromName(AccountDetails.bgColour);
        }

        
    }
}
