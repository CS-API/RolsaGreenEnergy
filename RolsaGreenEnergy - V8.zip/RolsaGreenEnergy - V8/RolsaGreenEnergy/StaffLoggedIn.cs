﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RolsaGreenEnergy
{
    public partial class StaffLoggedIn : Form
    {
        public StaffLoggedIn()
        {
            InitializeComponent();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            //Takes the user tho the booking page
            Booking booking = new Booking();
            booking.ShowDialog();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            //Opens the Settings page
            Settings settings = new Settings();
            settings.ShowDialog();
            //When the settings page is closed if the user logged out this page will also close and take them back to the account page
            if (AccountDetails.IsLoggedIn == false)
            {
                this.Hide();
                Login account = new Login();
                account.ShowDialog();
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            //takes user to the home page
            homePage homepage = new homePage();
            homepage.ShowDialog();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            //Takes user to information page
            Information information = new Information();
            information.ShowDialog();
        }

        private void StaffLoggedIn_Load(object sender, EventArgs e)
        {
            //Automatically enters the users detais into the text boxs
            txtEmail.Text = AccountDetails.UserName;
            txtPass.Text = AccountDetails.password;

            //Changes the background colour if the user has changed it
            this.BackColor = Color.FromName(AccountDetails.bgColour);

            //Find the user bookings and prints them out into a list
            string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("SelectBookings", sqlConnection);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(command);

            DataTable dt = new DataTable();

            command.Parameters.AddWithValue("@Email", AccountDetails.UserName);


            sqlConnection.Open();

            sd.Fill(dt);

            sqlConnection.Close();

            //Finds all the user bookings and insert them into the list box
            foreach (DataRow dr in dt.Rows)
            {
                string id = dr["Id"].ToString();
                string Email = dr["Email"].ToString();
                string Address = dr["Address"].ToString();
                string Type = dr["Type"].ToString();
                string Date = dr["Date"].ToString();

                string fullBooking = (id + " " + Email + " " + Address + " " + Type + " " + Date);

                listBox1.Items.Add(fullBooking);
            }

            //Tells the user they have no bookings
            if (listBox1.Items.Count <= 0)
            {
                listBox1.Items.Add("No Bookings found");
            }

            //Find all of the users bookings
            string ConnectionString2 = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection2 = new SqlConnection(ConnectionString2);
            SqlCommand command2 = new SqlCommand("SelectAllBookings", sqlConnection2);
            command2.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd2 = new SqlDataAdapter(command2);

            DataTable dt2 = new DataTable();

            sqlConnection2.Open();

            sd2.Fill(dt2);

            sqlConnection2.Close();

            //Finds all bookings so the staff can see them
            foreach (DataRow dr2 in dt2.Rows)
            {
                string id = dr2["Id"].ToString();
                string Email = dr2["Email"].ToString();
                string Address = dr2["Address"].ToString();
                string Type = dr2["Type"].ToString();
                string Date = dr2["Date"].ToString();

                string fullBooking = (id + " " + Email + " " + Address + " " + Type + " " + Date);

                listBox2.Items.Add(fullBooking);
            }

            //Tells staff there is no bookings
            if (listBox2.Items.Count <= 0)
            {
                listBox2.Items.Add("No Bookings found");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //shows the password
            if (checkBox1.Checked)
            {
                txtPass.PasswordChar = '\0';
            }
            else
            {
                txtPass.PasswordChar = '*';
            }
        }

        private void btnChangePass_Click(object sender, EventArgs e)
        {
            //shows the change password controls
            groupBox1.Show();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            //Shows new password
            if(checkBox2.Checked)
            {
                txtNewPass.PasswordChar = '\0';
            }
            else
            {
                txtNewPass.PasswordChar = '*';
            }
        }

        private void txtCancel_Click(object sender, EventArgs e)
        {
            //Hide show password controls
            groupBox1.Hide();
        }

        private void txtConfirm_Click(object sender, EventArgs e)
        {
            //New Password variable
            string newPassword = txtNewPass.Text;
            //Checks if the password isnt entered
            if (newPassword.Length == 0 || newPassword == "New Password....")
            {
                MessageBox.Show("Make sure to enter a new password or cancel", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                try
                {
                    //Updates the password coloumn in Accounts with the user new password
                    string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";
                    SqlConnection sqlConnection = new SqlConnection(ConnectionString);
                    SqlCommand command = new SqlCommand("ChangePass", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Password", newPassword);
                    command.Parameters.AddWithValue("@Email", AccountDetails.UserName);

                    sqlConnection.Open();

                    command.ExecuteNonQuery();

                    sqlConnection.Close();

                    MessageBox.Show("Success, Password Changed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    groupBox1.Hide();
                    txtPass.Text = newPassword;
                }
                catch
                {
                    MessageBox.Show("Error, Password not changed", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {

            try
            {
                int IdLength = 1;
                bool space = false;
                //Trys to delete user bookings
                //Check if a booking isnt selected
                string deleteId = (string)listBox1.SelectedItem ?? "".ToString();


                //Check the id stoo see if its more than one character
                while (space == false)
                {
                    string id = deleteId.Substring(0, IdLength);

                    bool whiteSpace = id.Contains(" ");
                    if (whiteSpace == false)
                    {
                        IdLength = IdLength + 1;
                    }
                    else
                    {
                        space = true;
                        finalId = id.Replace(" ", "");


                    }

                }

                try
                {
                    //Deletes the booking.
                    string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";
                    SqlConnection sqlConnection = new SqlConnection(ConnectionString);
                    SqlCommand command = new SqlCommand("RemoveBooking", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Id", finalId);

                    sqlConnection.Open();
                    command.ExecuteNonQuery();
                    sqlConnection.Close();

                    MessageBox.Show("Success, Booking deleted", "Booking Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);



                }
                catch
                {
                    MessageBox.Show("Error, Booking not deleted", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("Make sure you select a booking to delete", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error); 
            }
        }

        private void txtRefresh_Click(object sender, EventArgs e)
        {
            //refreshes the list box to see any new bookings.
            listBox1.Items.Clear();
            string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("SelectBookings", sqlConnection);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(command);

            DataTable dt = new DataTable();

            command.Parameters.AddWithValue("@Email", AccountDetails.UserName);


            sqlConnection.Open();

            sd.Fill(dt);

            sqlConnection.Close();

            foreach (DataRow dr in dt.Rows)
            {
                string id = dr["Id"].ToString();
                string Email = dr["Email"].ToString();
                string Address = dr["Address"].ToString();
                string Type = dr["Type"].ToString();
                string Date = dr["Date"].ToString();

                string fullBooking = (id + " " + Email + " " + Address + " " + Type + " " + Date);

                listBox1.Items.Add(fullBooking);
            }

            if (listBox1.Items.Count <= 0)
            {
                listBox1.Items.Add("No Bookings found");
            }
        }

        private void txtAllRefresh_Click(object sender, EventArgs e)
        {

            //Refresh all the user bookings
            listBox2.Items.Clear();
            string ConnectionString2 = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection2 = new SqlConnection(ConnectionString2);
            SqlCommand command2 = new SqlCommand("SelectAllBookings", sqlConnection2);
            command2.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd2 = new SqlDataAdapter(command2);

            DataTable dt2 = new DataTable();

            sqlConnection2.Open();

            sd2.Fill(dt2);

            sqlConnection2.Close();

            foreach (DataRow dr2 in dt2.Rows)
            {
                string id = dr2["Id"].ToString();
                string Email = dr2["Email"].ToString();
                string Address = dr2["Address"].ToString();
                string Type = dr2["Type"].ToString();
                string Date = dr2["Date"].ToString();

                string fullBooking = (id + " " + Email + " " + Address + " " + Type + " " + Date);

                listBox2.Items.Add(fullBooking);
            }

            if (listBox2.Items.Count <= 0)
            {
                listBox2.Items.Add("No Bookings found");
            }
        }
        string finalId;

        private void txtUserRemove_Click(object sender, EventArgs e)
        {
            try
            {
                int IdLength = 1;
                bool space = false;
                //Trys to delete user bookings
                //Check if a booking isnt selected
                string deleteId = (string)listBox2.SelectedItem ?? "".ToString();



                while (space == false)
                {
                    string id = deleteId.Substring(0, IdLength);

                    //checks the length of the id
                    bool whiteSpace = id.Contains(" ");
                    if (whiteSpace == false)
                    {
                        IdLength = IdLength + 1;
                    }
                    else
                    {
                        space = true;
                        finalId = id.Replace(" ", "");


                    }

                }



                try
                {
                    //Removes user booking
                    string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";
                    SqlConnection sqlConnection = new SqlConnection(ConnectionString);
                    SqlCommand command = new SqlCommand("RemoveBooking", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Id", finalId);

                    sqlConnection.Open();
                    command.ExecuteNonQuery();
                    sqlConnection.Close();

                    MessageBox.Show("Success, Booking deleted", "Booking Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);



                }
                catch
                {
                    MessageBox.Show("Error, Booking not deleted", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("Make sure you select a booking to delete", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Sees if the user has admin permissions, if not they cant acces the admin page.
            if (AccountDetails.Admin == false)
            {
                MessageBox.Show("You do not have admin permissions", "ERROR");
            }
            else
            {
                AdminPage adminPage = new AdminPage();
                adminPage.Show();
            }
        }
    }
}
