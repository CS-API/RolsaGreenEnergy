﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using MailKit.Net.Smtp;
using MailKit;
using MimeKit;
using SmtpClient = MailKit.Net.Smtp.SmtpClient;
using System.Net;
using Microsoft.SharePoint.Mobile.WebControls;
using System.Data.SqlClient;


namespace RolsaGreenEnergy
{
    public partial class homePage : Form
    {

        
        public homePage()
        {
            InitializeComponent();
        }


        private void btnInfo_Click(object sender, EventArgs e)
        {
            // Opens the Information page
            this.Hide();
            Information info = new Information();
            info.ShowDialog();
            
        }

        

        private void btnAccount_Click(object sender, EventArgs e)
        {
        
            //Checks if the user is logged in and see if they are staff so if they go to the account page they either go to their account or goes to login.
            if (AccountDetails.IsLoggedIn == true)
            {
                if (AccountDetails.staff == false)
                {
                    this.Hide();
                    LoggedInAccount loggedInAccount = new LoggedInAccount();
                    loggedInAccount.ShowDialog();
                }
                else
                {
                    this.Hide();
                    StaffLoggedIn staffAccount = new StaffLoggedIn();
                    staffAccount.ShowDialog();
                }

            }
            else
            {
                this.Hide();
                Login account = new Login();
                account.ShowDialog();
                
            }
        }

        private void homePage_Load(object sender, EventArgs e)
        {
            //Changes the background colour if the user has changed it on their settings
            this.BackColor = Color.FromName(AccountDetails.bgColour);
        }

   
        private void button2_Click(object sender, EventArgs e)
        {
            //Checks to see if the user is looged in so they can make a booking, otherwise it will give them a warning tell ing them to log in
            if (AccountDetails.IsLoggedIn == true)
            {
                Booking booking = new Booking();
                booking.ShowDialog();
            }
            else
            {
                MessageBox.Show("You need to log in to make a booking", "Log In", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
