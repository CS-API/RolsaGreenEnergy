﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RolsaGreenEnergy
{
    public partial class Information : Form
    {
        public Information()
        {
            InitializeComponent();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            //Opens the home page and hides this window
            this.Hide();
            homePage homePage = new homePage();
            homePage.ShowDialog();
            
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {

            //Calculater variables
            float electricity, gas, water, carTravel, airTravel;
            float carbonFootprint;

            try
            {
                //Calculate the users Carbon FootPrint and output it into the box
                electricity = (float)(float.Parse(txtElectricity.Text) * 0.233);
                gas = (float)(float.Parse(txtGas.Text) * 0.184);
                water = (float)(float.Parse(txtWater.Text) * 0.149);
                carTravel = (float)(float.Parse(txtCarTravel.Text) * 0.168);
                airTravel = (float)(float.Parse(txtAirTravel.Text) * 0.184);
                carbonFootprint = electricity + gas + water + airTravel + carTravel;
                //Checking to see if the user has entered an unrealistic number. makes sure the user enters acurate data.
                if (carbonFootprint > 7000)
                {
                    //Checks to see if the carbon footprint is too high
                    MessageBox.Show("Make sure you enter the correct values");
                    txtElectricity.Clear();
                    txtGas.Clear();
                    txtWater.Clear();
                    txtCarTravel.Clear();
                    txtAirTravel.Clear();

                    txtElectricity.Text = "Electricity - kWh....";
                    txtGas.Text = "Gas - kWh....";
                    txtWater.Text = "Cubic meter";
                    txtCarTravel.Text = "Car Travel - pkm....";
                    txtAirTravel.Text = "Air Travel - pkm....";
                }
                else
                {
                    //Outputs the user carbon footprint
                    txtCarbonFootprint.Text = (carbonFootprint + " Kg");
                    MessageBox.Show("Succesfully calculated");
                }
                

                //Clears the users inputs and replaces them with what originaly was there so the user can calculate another carbon footprint
                txtElectricity.Clear();
                txtGas.Clear();
                txtWater.Clear();
                txtCarTravel.Clear();
                txtAirTravel.Clear();

                txtElectricity.Text = "Electricity - kWh....";
                txtGas.Text = "Gas - kWh....";
                txtWater.Text = "Cubic meter";
                txtCarTravel.Text = "Car Travel - pkm....";
                txtAirTravel.Text = "Air Travel - pkm....";
            }
            catch
            {
                //This error will show up if the user has entered the incorrect data and clears all their inputs
                MessageBox.Show("Make sure you have entered the correct data");
                txtElectricity.Clear();
                txtGas.Clear();
                txtWater.Clear();
                txtCarTravel.Clear();
                txtAirTravel.Clear();
                txtCarbonFootprint.Clear();

                txtElectricity.Text = "Electricity - kWh....";
                txtGas.Text = "Gas - kWh....";
                txtWater.Text = "Cubic meter";
                txtCarTravel.Text = "Car Travel - pkm....";
                txtAirTravel.Text = "Air Travel - pkm....";
            }

        }

        private void btnAccount_Click(object sender, EventArgs e)
        {
            //Checks if the user is logged in and if they are staff and send them to their account or the log in page
            if (AccountDetails.IsLoggedIn == true)
            {
                if (AccountDetails.staff == false)
                {
                    this.Hide();
                    LoggedInAccount loggedInAccount = new LoggedInAccount();
                    loggedInAccount.ShowDialog();
                }
                else
                {
                    this.Hide();
                    StaffLoggedIn staffAccount = new StaffLoggedIn();
                    staffAccount.ShowDialog();
                }

            }
            else
            {
                this.Hide();
                Login account = new Login();
                account.ShowDialog();

            }

        }

        private void Information_Load(object sender, EventArgs e)
        {
            //Sets the background if the User has changed it.
            this.BackColor = Color.FromName(AccountDetails.bgColour);
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            //Checks to see if the user is looged in so they can make a booking, otherwise it will give them a warning tell ing them to log in
            if (AccountDetails.IsLoggedIn == true)
            {
                Booking booking = new Booking();
                booking.ShowDialog();
            }
            else
            {
                MessageBox.Show("You need to log in to make a booking", "Log In", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
