﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RolsaGreenEnergy
{
    public partial class AdminPage : Form
    {
        public AdminPage()
        {
            InitializeComponent();
        }

        private void AdminPage_Load(object sender, EventArgs e)
        {
            //Shows all the users that use the app.
            string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\Versions\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("FindAccounts", sqlConnection);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(command);

            DataTable dt = new DataTable();

            sqlConnection.Open();

            sd.Fill(dt);

            sqlConnection.Close();

            foreach (DataRow dr in dt.Rows)
            {
                string id = dr["Id"].ToString();
                string email = dr["email"].ToString();
                string staffPermissions = dr["StaffPermisions"].ToString();
                string adminPermissions = dr["AdminPermissions"].ToString();

                string user = id + " " + email + " " + staffPermissions + " " + adminPermissions;

                listBox1.Items.Add(user);
            }
        }
        string finalId;
        

        private void btnGiveStaffPermissions_Click(object sender, EventArgs e)
        {
            try
            {
                //Check if a booking isnt selected
                string user = (string)(listBox1.SelectedItem ?? "".ToString());
                int IdLength = 1;
                bool space = false;


                while (space == false)
                {
                    string id = user.Substring(0, IdLength);

                    //checks the length of the id
                    bool whiteSpace = id.Contains(" ");
                    if (whiteSpace == false)
                    {
                        IdLength = IdLength + 1;
                    }
                    else
                    {
                        space = true;
                        finalId = id.Replace(" ", "");


                    }

                }



                try
                {
                    //Changes Staff permissions
                    string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\Versions\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";
                    SqlConnection sqlConnection = new SqlConnection(ConnectionString);
                    SqlCommand command = new SqlCommand("GiveStaffPermissions", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Id", finalId);
                    command.Parameters.AddWithValue("@StaffPermissions", "True");

                    sqlConnection.Open();
                    command.ExecuteNonQuery();
                    sqlConnection.Close();

                    MessageBox.Show("Success, Staff Permissions Changed", "Satff Permissions", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Close();

                }
                catch
                {
                    MessageBox.Show("Error, Permissions not changed", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                }
                catch
                {
                    MessageBox.Show("Make sure you select a user", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            

            try
            {
                int IdLength = 1;
                bool space = false;
                //Trys delete user
                //Check if a user isnt selected
                string user = (string)listBox1.SelectedItem ?? "".ToString();


                //Check the id stoo see if its more than one character
                while (space == false)
                {
                    string id = user.Substring(0, IdLength);

                    bool whiteSpace = id.Contains(" ");
                    if (whiteSpace == false)
                    {
                        IdLength = IdLength + 1;
                    }
                    else
                    {
                        space = true;
                        finalId = id.Replace(" ", "");


                    }

                }

                try
                {
                    //Deletes user
                    string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\Versions\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";
                    SqlConnection sqlConnection = new SqlConnection(ConnectionString);
                    SqlCommand command = new SqlCommand("DeleteUser", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Id", finalId);

                    sqlConnection.Open();
                    command.ExecuteNonQuery();
                    sqlConnection.Close();

                    MessageBox.Show("Success, User deleted", "User Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();


                }
                catch
                {
                    MessageBox.Show("Error, User not deleted", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("Make sure you select a User to delete", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    
}

