﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RolsaGreenEnergy
{
    internal class AccountDetails
    {
        public static String UserName = "";
        public static String password = "";
        public static bool IsLoggedIn = false;
        public static String bgColour = "White";
        public static bool staff = false;
        public static bool Admin = false;

    }
}
