﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RolsaGreenEnergy
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Allows the user to cancel booking
            this.Close();
        }

        private void addressClick(object sender, EventArgs e)
        {
            //Clears the address text box so the user can enter their own.
            txtAddress.Text = "";
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string address = txtAddress.Text;
            string bookingType = comboBox1.Text;
            string email = AccountDetails.UserName;
            string date = monthCalendar1.SelectionRange.Start.ToShortDateString();
            bool dateTaken = false;


            //User makes a booking
            string ConnectionString2 = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection2 = new SqlConnection(ConnectionString2);
            SqlCommand command2 = new SqlCommand("SelectAllBookingDates", sqlConnection2);
            command2.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(command2);

            DataTable dt = new DataTable();

            sqlConnection2.Open();

            sd.Fill(dt);

            sqlConnection2.Close();

            foreach (DataRow dr in dt.Rows)
            {
                //Checks if date is taken
                if (date.Equals(dr["Date"]))
                {
                    dateTaken = true;
                    break;
                }
                else
                {
                    dateTaken = false;
                }
 
            }

            if (dateTaken == false)
            {
                //Makes a booking if date isnt took
                try
                {
                    string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";
                    SqlConnection sqlConnection = new SqlConnection(ConnectionString);
                    SqlCommand command = new SqlCommand("AddBooking", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Address", address);
                    command.Parameters.AddWithValue("@Type", bookingType);
                    command.Parameters.AddWithValue("@Date", date);

                    sqlConnection.Open();
                    command.ExecuteNonQuery();
                    sqlConnection.Close();

                    MessageBox.Show("Success, Booking placed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                catch
                {
                    MessageBox.Show("Error, Booking not placed", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                //Tells the user that the date is alreaden taken and needs to select another
                MessageBox.Show("Date Already Taken", "Date Taken", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAddress.Text = "Address....";
                comboBox1.Text = "";
            }



        }
    }
}
