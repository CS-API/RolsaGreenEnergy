﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RolsaGreenEnergy
{
    public partial class LoggedInAccount : Form
    {

        
        public LoggedInAccount()
        {
            InitializeComponent();
        }

        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void LoggedInAccount_Load(object sender, EventArgs e)
        {
            

            //Automatically enters the users detais into the text boxs
            txtEmail.Text = AccountDetails.UserName;
            txtPass.Text = AccountDetails.password;

            //Changes the background colour if the user has changed it
            this.BackColor = Color.FromName(AccountDetails.bgColour);


            //Find the user bookings and prints them out into a list
            string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("SelectBookings", sqlConnection);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(command);

            DataTable dt = new DataTable();

            command.Parameters.AddWithValue("@Email", AccountDetails.UserName);
            

            sqlConnection.Open();

            sd.Fill(dt);

            sqlConnection.Close();

            foreach(DataRow dr in dt.Rows)
            {
                string id = dr["Id"].ToString();
                string Email = dr["Email"].ToString();
                string Address = dr["Address"].ToString();
                string Type = dr["Type"].ToString();
                string Date = dr["Date"].ToString();

                string fullBooking = (id + " " + Email + " " + Address + " " + Type + " " + Date);

                listBox1.Items.Add(fullBooking);
            }

            //Tells the user no bookings have been found
            if (listBox1.Items.Count <= 0)
            {
                listBox1.Items.Add("No Bookings found");
            }


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //Allows the user to show and hide their password
            if (checkBox1.Checked)
            {
                txtPass.PasswordChar = '\0';
            }
            else
            {
                txtPass.PasswordChar = '*';
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            //Opens the home page and closes this page
            this.Hide();
            homePage home = new homePage();
            home.ShowDialog();
            
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            //Opens the information page and closes this page
            this.Hide();
            Information information = new Information();
            information.ShowDialog();
            
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            //Opens the Settings page
            Settings settings = new Settings();
            settings.ShowDialog();
            //When the settings page is closed if the user logged out this page will also close and take them back to the account page
            if ( AccountDetails.IsLoggedIn == false)
            {
                this.Hide();
                Login account = new Login();
                account.ShowDialog();
            }

        }

        private void btnChangePass_Click(object sender, EventArgs e)
        {
            //If the user wants to change their password the controls will show.
            groupBox1.Show();

            
        }

        private void newPassClick(object sender, EventArgs e)
        {
            //Clears the password so the user can enter their new one and changes the password character so no one can see it.
            txtNewPass.Text = "";
            txtNewPass.PasswordChar = '*';
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            //Allows the user to show and hide their new password
            if (checkBox2.Checked)
            {
                txtNewPass.PasswordChar = '\0';
            }
            else
            {
                txtNewPass.PasswordChar = '*';
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //New Password variable
            string newPassword = txtNewPass.Text;

            try
            {
                //Updates the password coloumn in Accounts with the user new password
                string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";
                SqlConnection sqlConnection = new SqlConnection(ConnectionString);
                SqlCommand command = new SqlCommand("ChangePass", sqlConnection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@Password", newPassword);
                command.Parameters.AddWithValue("@Email", AccountDetails.UserName);

                sqlConnection.Open();

                command.ExecuteNonQuery();

                sqlConnection.Close();

                MessageBox.Show("Success, Password Changed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                groupBox1.Hide();
                txtPass.Text = newPassword;
            }
            catch
            {
                MessageBox.Show("Error, Password not changed", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtCancel_Click(object sender, EventArgs e)
        {
            //If the user doesnt want to update their password they can cancel and the controls will close
            groupBox1.Hide();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            //Checks to see if the user is looged in so they can make a booking, otherwise it will give them a warning tell ing them to log in
            if (AccountDetails.IsLoggedIn == true)
            {
                Booking booking = new Booking();
                booking.ShowDialog();
            }
            else
            {
                MessageBox.Show("You need to log in to make a booking", "Log In", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        String finalId;
        private void btnRemove_Click(object sender, EventArgs e)
        {
            int IdLength = 1;
            bool space = false;
            //Trys to delete user bookings
            string deleteId = listBox1.SelectedItem.ToString();


            //Checks id length
            while (space == false)
            {
                string id = deleteId.Substring(0, IdLength);

                bool whiteSpace = id.Contains(" ");
                if (whiteSpace == false)
                {
                    IdLength = IdLength + 1;
                }
                else
                {
                    space = true;
                    finalId = id.Replace(" ", "");


                }

            }

            try
            {
                //Deletes user booking
                string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";
                SqlConnection sqlConnection = new SqlConnection(ConnectionString);
                SqlCommand command = new SqlCommand("RemoveBooking", sqlConnection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@Id", finalId);

                sqlConnection.Open();
                command.ExecuteNonQuery();
                sqlConnection.Close();

                MessageBox.Show("Success, Booking deleted", "Booking Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                

            }
            catch
            {
                MessageBox.Show("Error, Booking not deleted", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void txtRefresh_Click(object sender, EventArgs e)
        {
            //Refreshes the listbox so the user can see new bookings
            listBox1.Items.Clear();
            string ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\EXAM1024\\OneDrive - Middlesbrough College\\Exams\\Task 2\\RolsaGreenEnergy - V3\\RolsaEnergyDB.mdf\";Integrated Security=True;Connect Timeout=30";

            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("SelectBookings", sqlConnection);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(command);

            DataTable dt = new DataTable();

            command.Parameters.AddWithValue("@Email", AccountDetails.UserName);


            sqlConnection.Open();

            sd.Fill(dt);

            sqlConnection.Close();

            foreach (DataRow dr in dt.Rows)
            {
                string id = dr["Id"].ToString();
                string Email = dr["Email"].ToString();
                string Address = dr["Address"].ToString();
                string Type = dr["Type"].ToString();
                string Date = dr["Date"].ToString();

                string fullBooking = (id + " " + Email + " " + Address + " " + Type + " " + Date);

                listBox1.Items.Add(fullBooking);
            }

            //Tells the user they have no bookings
            if (listBox1.Items.Count <= 0)
            {
                listBox1.Items.Add("No Bookings found");
            }

        }

        
    }
}
